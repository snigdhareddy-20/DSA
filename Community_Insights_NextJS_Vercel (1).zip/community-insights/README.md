# Community Insights – Community Detection Platform

A complete Next.js + TypeScript DSA web application for weighted social-network analysis and Louvain-style community detection.

## DSA mapping from the Java project

- `lib/graph.ts` ↔ Java `Graph.java`: weighted undirected adjacency list, add/remove users, weighted edges, BFS, DFS, degree and weighted degree.
- `lib/louvain.ts` ↔ Java community detector: deterministic local-moving modularity optimization.
- `lib/metrics.ts` ↔ Java `Metrics.java`: density, average degree, total strength, community summaries and user statistics.
- `lib/csv-parser.ts` handles reliable quoted CSV input with Papa Parse.
- `app/api/analyze/route.ts` is the deployed backend entry point. No Java process is required on Vercel.

## Duplicate-edge policy

The graph is undirected. Repeated `A,B` or reversed `B,A` rows are the same edge and their weights are **summed**. Self-loops and rows with missing users or non-positive/non-numeric weights are skipped and returned as warnings.

## Louvain implementation note

This project implements the genuine weighted modularity local-moving phase: each node begins in its own community, candidate moves are limited to neighboring communities, each move is accepted only if weighted undirected modularity improves, and passes repeat until convergence or an iteration limit. For readability in a college DSA project, modularity is recomputed when evaluating candidate moves. It does **not** implement Louvain's graph-coarsening/multi-level aggregation phase, so it is intended for small/medium teaching datasets rather than very large production graphs.

## Run locally

Requirements: Node.js 20+.

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

Production build:

```bash
npm run build
npm start
```

## API

### `POST /api/analyze`
Send `multipart/form-data` with a `file` field containing a `.csv` file (max 10 MB).

Required columns:

```csv
source,target,weight
Rahul,Priya,15
Rahul,Amit,12
```

Returns calculated network metrics, community assignments, community summaries, user statistics and graph data.

### `GET /api/health`
Returns API status JSON.

## Vercel deployment

1. Push this folder to a GitHub repository.
2. Sign in to Vercel and choose **Add New → Project**.
3. Import the GitHub repository.
4. Vercel detects Next.js automatically. Keep the default build command (`next build`).
5. Click **Deploy**.

No database, API key, secret, Java server, or environment variable is required. Uploaded CSVs are processed in memory and are not permanently stored by this application.

## Project structure

```text
app/
  api/analyze/route.ts
  api/health/route.ts
  documentation/page.tsx
  about/page.tsx
  page.tsx
components/
  Dashboard.tsx
  NetworkGraph.tsx
lib/
  graph.ts
  louvain.ts
  metrics.ts
  csv-parser.ts
  analysis.ts
  sample-data.ts
types/index.ts
```
