import {Graph} from './graph';import {louvain} from './louvain';import {buildResult} from './metrics';import {parseCSV} from './csv-parser';
export function analyzeCSV(text:string){const p=parseCSV(text),g=new Graph();for(const e of p.edges)g.addInteraction(e.source,e.target,e.weight);const l=louvain(g);return buildResult(g,l.assignment,p.loadedRows,p.skippedRows,p.warnings)}
