import type { Edge } from '@/types';
export class Graph {
  private adj=new Map<string,Map<string,number>>();
  addUser(id:string){const x=id.trim(); if(!x||this.adj.has(x)) return false; this.adj.set(x,new Map()); return true}
  containsUser(id:string){return this.adj.has(id)}
  addInteraction(a:string,b:string,w:number){if(a===b||!Number.isFinite(w)||w<=0) return false; if(!this.adj.has(a))this.addUser(a); if(!this.adj.has(b))this.addUser(b); const old=this.adj.get(a)!.get(b)??0; const nw=old+w; this.adj.get(a)!.set(b,nw); this.adj.get(b)!.set(a,nw); return true}
  removeUser(id:string){if(!this.adj.has(id))return false; for(const n of this.adj.get(id)!.keys())this.adj.get(n)?.delete(id); this.adj.delete(id); return true}
  getNeighbors(id:string){return new Map(this.adj.get(id)??[])}
  getUsers(){return [...this.adj.keys()].sort()}
  getDegree(id:string){return this.adj.get(id)?.size??0}
  getWeightedDegree(id:string){return [...(this.adj.get(id)?.values()??[])].reduce((a,b)=>a+b,0)}
  getEdges():Edge[]{const out:Edge[]=[]; const seen=new Set<string>(); for(const [a,ns] of this.adj)for(const [b,w] of ns){const k=[a,b].sort().join('\0');if(!seen.has(k)){seen.add(k);out.push({source:a,target:b,weight:w})}} return out}
  getEdgeCount(){return this.getEdges().length}
  getTotalInteractionStrength(){return this.getEdges().reduce((s,e)=>s+e.weight,0)}
  bfs(start:string){if(!this.adj.has(start))return[];const q=[start],seen=new Set([start]),out:string[]=[];while(q.length){const u=q.shift()!;out.push(u);for(const v of [...this.getNeighbors(u).keys()].sort())if(!seen.has(v)){seen.add(v);q.push(v)}}return out}
  dfs(start:string){const out:string[]=[],seen=new Set<string>();const go=(u:string)=>{seen.add(u);out.push(u);for(const v of [...this.getNeighbors(u).keys()].sort())if(!seen.has(v))go(v)};if(this.adj.has(start))go(start);return out}
}
