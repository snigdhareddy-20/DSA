import {NextResponse} from 'next/server';export function GET(){return NextResponse.json({status:'ok',service:'Community Insights API',timestamp:new Date().toISOString()})}
