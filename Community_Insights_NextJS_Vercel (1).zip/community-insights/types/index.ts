export type Edge={source:string;target:string;weight:number};
export type UserStat={id:string;community:number;degree:number;weightedDegree:number;connections:number};
export type Community={id:number;members:string[];size:number;internalStrength:number;percentage:number};
export type AnalysisResult={users:number;interactions:number;loadedRows:number;skippedRows:number;totalStrength:number;densityPercent:number;averageDegree:number;mostConnectedUser:string|null;highestWeightedDegree:number;communityCount:number;modularity:number;communities:Community[];userStats:UserStat[];graph:{nodes:{id:string;community:number;weightedDegree:number}[];edges:Edge[]};warnings:string[]};
